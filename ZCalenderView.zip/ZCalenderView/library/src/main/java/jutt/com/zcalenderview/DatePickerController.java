package jutt.com.zcalenderview;

public interface DatePickerController {

	public abstract void onDayOfMonthSelected(int year, int month, int day);

}